
      <div id="sidebar-area" class="col-md-4">
      <?php
if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('primary-sidebar') ) :
endif; ?>
</div>

      

