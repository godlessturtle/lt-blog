

<?php do_action('lt_blog_top_footer_action'); ?>


</body>


</html>


<?php wp_footer(); ?>