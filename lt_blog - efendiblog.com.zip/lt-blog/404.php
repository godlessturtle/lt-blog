

<?php get_header(); ?>
<!-- Page Content -->
<div class="container">
  <div class="row">
    <!-- Blogpost1  -->
    <div id="content-area" style="height:250px; padding:5px 20px 50px 20px;" class="col-md-12">0
    <div class="alert alert-danger" style="margin-top:75px;" role="alert">
    <h3>Hata! böyle bir sayfa bulunamadı. <br>Bunun yerine şunu deneyebilirsiniz : <a href="<?php bloginfo(url); ?>">Anasayfa</a></h3>
     </div>
    </div>
   </div>
</div>
<?php get_footer(); ?>