<!-- Post - <?php the_ID(); $author = get_the_author(); ?> Basla -->
<article id="icerik_kutu" class="col-md-6 yazi-<?php the_ID(); ?>">
  <?php do_action('lt_blog_post_action'); ?>
</article>
<!-- ./Post <?php the_ID(); ?> Bitir -->